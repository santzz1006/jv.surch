'use strict';
importScripts('alerts.js','cloud.js','catalog-service.js','overlay-lifecycle.js');
let polling=false;
async function configure(){const s=await chrome.storage.local.get('goofishBrCloud');if(s.goofishBrCloud?.alerts){if(!await chrome.alarms.get('gb-alerts'))await chrome.alarms.create('gb-alerts',{periodInMinutes:30});}else await chrome.alarms.clear('gb-alerts');}
async function poll(){if(polling)return;polling=true;try{const c=await GBC.config();if(!c.alerts)return;const events=await GBC.call('/api/alerts');const stored=await chrome.storage.local.get('gbNotified'),last=Number(stored.gbNotified)||0;const fresh=events.filter(e=>e.id>last);const permission=await chrome.permissions.contains({permissions:['notifications']});if(permission&&fresh.length){await chrome.notifications.create('gb-alerts',{type:'basic',iconUrl:'icons/128.png',title:'Goofish Br · Seus alertas',message:fresh.length===1?fresh[0].message:fresh.length+' atualizações nos seus anúncios. Abra o painel para conferir.'});await chrome.storage.local.set({gbNotified:Math.max(last,...fresh.map(e=>e.id))});}await chrome.storage.local.set({gbCloudStatus:'Alertas consultados em '+new Date().toLocaleString('pt-BR')});}catch(e){await chrome.storage.local.set({gbCloudStatus:e.message});}finally{polling=false;}}
chrome.runtime.onInstalled.addListener(configure);chrome.runtime.onStartup.addListener(configure);chrome.alarms.onAlarm.addListener(a=>{if(a.name==='gb-alerts')poll();});chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.goofishBrCloud)configure();});chrome.notifications?.onClicked?.addListener(id=>{if(id==='gb-alerts')chrome.tabs.create({url:chrome.runtime.getURL('dashboard.html#alerts')});});configure().catch(()=>{});

let localPolling=false;
async function configureLocalAlerts(){const s=await GBAlerts.state();if(s.enabled)await chrome.alarms.create('gb-local-alerts',{periodInMinutes:30});else await chrome.alarms.clear('gb-local-alerts');}
chrome.alarms.onAlarm.addListener(async a=>{if(a.name!=='gb-local-alerts'||localPolling)return;localPolling=true;try{await GBAlerts.check();}catch(e){await chrome.storage.local.set({gbCloudStatus:e.message});}finally{localPolling=false;}});
chrome.storage.onChanged.addListener((c,area)=>{if(area==='local'&&c.gbLocalAlerts&&c.gbLocalAlerts.oldValue?.enabled!==c.gbLocalAlerts.newValue?.enabled)configureLocalAlerts().catch(()=>{});});
configureLocalAlerts().catch(()=>{});

chrome.notifications?.onClicked?.addListener(async id=>{if(id!=='gb-local-alerts')return;await chrome.storage.local.set({gbOpenAlerts:true});try{await chrome.action.openPopup();}catch{await chrome.storage.local.set({gbCloudStatus:'Abra a extensão para conferir seus alertas.'});}});
